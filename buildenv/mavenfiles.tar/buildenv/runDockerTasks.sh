#!/bin/bash

dir=$(cd -P -- "$(dirname -- "$0")" && pwd -P)
(
        cd $dir/..
        echo "dir is $dir (script is $0)"
        export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64/ 
        export MAVEN_CONFIG=/var/lib/maven/ 
        export MAVEN_OPTS="-Xmx2048m -XX:MaxDirectMemorySize=512m -XX:+HeapDumpOnOutOfMemoryError -Dfile.encoding=UTF-8" 
        timeout 3h mvn jar:jar compile package ${MAVEN_ARGS}
        timeout 1h $dir/mkindex.sh
)
