inkscape -z -e MessageVortexLogo_huge.png -w 14360 -h 15000 --export-background-opacity=0 --without-gui MessageVortexLogo.svg && \
inkscape -z -e MessageVortexLogo_big.png -w 1436 -h 1500 --export-background-opacity=0 --without-gui MessageVortexLogo.svg && \
inkscape -z -e MessageVortexLogo.png -w 128 -h 128 --export-background-opacity=0 --without-gui MessageVortexLogo.svg 


 